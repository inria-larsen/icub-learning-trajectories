%close the cpp program (that give order to gazebo)
b.clear();
b.addDouble(-1);    
port.write(b);
port.close;
clear all;