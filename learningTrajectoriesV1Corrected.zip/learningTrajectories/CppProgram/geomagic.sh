#!/bin/bash

export GTDD_HOME=/opt/geomagic_touch_device_driver
export LD_LIBRARY_PATH=/opt/geomagic_touch_device_driver/lib
export QT_PLUGIN_PATH=/opt/geomagic_touch_device_driver/lib/plugins
